"""
Measurement script for temperature and acceleration sensors.

This script handles the complete measurement cycle of temperature (DS18B20) and acceleration (ADXL345) sensors.
It initializes hardware, performs real-time measurements, and stores the data into an HDF5 file,
along with archiving relevant metadata JSON files.

Modules:
    - Setup of GPIO, temperature sensors, accelerometer.
    - Parallel measurement threads for temperature and acceleration.
    - Clean shutdown and data storage.

Author:
    Oliver Zhengzhong Gao

Version:
    ThermoVibe 1_1_0

Update:
    29.04.2025
"""

import os
import threading
import time

import adafruit_adxl34x
import board
import h5py
import numpy as np
import RPi.GPIO as GPIO
from w1thermsensor import Sensor, W1ThermSensor

from functions import m_json

# === Paths ===
PATH_SETUP = "./datasheets/setup_template.json"  # for example "./datasheets/setup_test.json"

# === Global Variables ===
temp_data = {}
temp_names = []
temp_sensors = []
acc_data = {}
threads = []
stop_event = threading.Event()


# === Measurement Functions ===
def measure_temperature(start_time: float) -> None:
    """Measures temperature periodically."""
    try:
        while not stop_event.is_set():
            for i, uuid in enumerate(temp_data):
                t_now = time.time() - start_time
                try:
                    T = temp_sensors[i].get_temperature()
                except Exception:
                    T = np.nan
                temp_data[uuid][0].append(T)
                temp_data[uuid][1].append(t_now)
                print(f"[TEMP] {temp_names[i]}: {T:.2f} °C at {t_now:.2f} s")
            time.sleep(1.0)
    except Exception as e:
        print("[ERROR] Temperature thread crashed:", e)


def measure_acceleration(start_time: float) -> None:
    """Measures acceleration continuously."""
    try:
        while not stop_event.is_set():
            t_now = time.time() - start_time
            x, y, z = accelerometer.acceleration
            acc_data[acc_uuid][0].append(x)
            acc_data[acc_uuid][1].append(y)
            acc_data[acc_uuid][2].append(z)
            acc_data[acc_uuid][3].append(t_now)
            print(f"[ACC] x={x:.2f}, y={y:.2f}, z={z:.2f} at {t_now:.2f} s")
            time.sleep(0.01)
    except Exception as e:
        print("[ERROR] Acceleration thread crashed:", e)


# === Main function ===
def main() -> None:
    """Main measurement function."""
    global temp_data, temp_names, temp_sensors, acc_data, accelerometer, acc_uuid

    # Load metadata
    metadata = m_json.get_metadata_from_setup(PATH_SETUP)

    # Setup GPIO
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(17, GPIO.OUT)
    GPIO.output(17, GPIO.HIGH)
    print("[INFO] Power ON")
    time.sleep(3)

    # Setup temperature sensors
    for i, uuid in enumerate(metadata["DS18B20"]["values"]):
        serial = metadata["DS18B20"]["serials"][i]
        temp_names.append(metadata["DS18B20"]["names"][i])
        temp_sensors.append(W1ThermSensor(Sensor.DS18B20, serial))
        temp_data[uuid] = [[], []]

    # Setup accelerometer
    i2c = board.I2C()
    acc_uuid = "acceleration_sensor"
    try:
        accelerometer = adafruit_adxl34x.ADXL345(i2c)
    except Exception as e:
        print("[ERROR] Failed to initialize ADXL345. Run i2cdetect to debug.")
        raise e

    acc_data[acc_uuid] = [[], [], [], []]  # x, y, z, t

    # Wait for user to start
    input("[INFO] Press ENTER to start measurement...")
    start_time = time.time()

    thread_temp = threading.Thread(target=measure_temperature, args=(start_time,))
    thread_acc = threading.Thread(target=measure_acceleration, args=(start_time,))

    threads.extend([thread_temp, thread_acc])

    for thread in threads:
        thread.start()

    # Wait for user to stop
    try:
        input("[INFO] Press ENTER to stop measurement...\n")
    except KeyboardInterrupt:
        print("[INFO] Keyboard interrupt received.")

    stop_event.set()
    for thread in threads:
        thread.join()

    # Power off
    GPIO.output(17, GPIO.LOW)
    print("[INFO] Power OFF")
    time.sleep(2)

    # Save measurement
    logname = input("[INPUT] Logging file name: ").strip()
    while not logname:
        logname = input("[RETRY] Logging file name (not empty): ").strip()

    logdir = os.path.join("data", logname)
    os.makedirs(logdir, exist_ok=True)
    h5_path = os.path.join(logdir, f"{logname}.hdf5")

    with h5py.File(h5_path, "w") as f:
        f.attrs["created"] = time.asctime(time.localtime())
        f.attrs["experiment"] = "combined_temp_vib"
        raw = f.create_group("RawData")

        for i, uuid in enumerate(temp_data):
            g = raw.create_group(
                "temperature sensor " + metadata["DS18B20"]["values"][i]
            )
            g.attrs["serial"] = metadata["DS18B20"]["serials"][i]
            g.attrs["name"] = metadata["DS18B20"]["values"][i]
            g.attrs["uuid"] = uuid
            g.create_dataset("temperature", data=np.array(temp_data[uuid][0])).attrs[
                "unit"
            ] = "°C"
            g.create_dataset("timestamp", data=np.array(temp_data[uuid][1])).attrs[
                "unit"
            ] = "s"

        g = raw.create_group(acc_uuid)
        g.attrs["name"] = "ADXL345 Accelerometer"
        g.create_dataset("acceleration_x", data=np.array(acc_data[acc_uuid][0])).attrs[
            "unit"
        ] = "m/s^2"
        g.create_dataset("acceleration_y", data=np.array(acc_data[acc_uuid][1])).attrs[
            "unit"
        ] = "m/s^2"
        g.create_dataset("acceleration_z", data=np.array(acc_data[acc_uuid][2])).attrs[
            "unit"
        ] = "m/s^2"
        g.create_dataset("timestamp", data=np.array(acc_data[acc_uuid][3])).attrs[
            "unit"
        ] = "s"

    print(f"[INFO] Measurement saved to {h5_path}")


if __name__ == "__main__":
    main()
