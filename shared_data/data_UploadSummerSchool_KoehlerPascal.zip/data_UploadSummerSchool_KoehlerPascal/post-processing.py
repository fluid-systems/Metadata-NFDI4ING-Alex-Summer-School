"""
Post-processing script for vibration and temperature measurements.

This script processes data from an HDF5 file, removes trends from the vibration signal,
and plots:
- Raw vibration magnitude and temperature
- Detrended vibration magnitude and temperature
- Frequency spectrum of the detrended vibration signal
Additionally, it serializes each plot into a JSON file using Plot Serializer with a unique Plot ID.

Author:
    Oliver Zhengzhong Gao

Version:
    ThermoVibe 1_1_0

Update:
    16.05.2025
"""

import os
import shutil
import uuid
from typing import Tuple

import h5py
import matplotlib.pyplot as plt
import numpy as np
from numpy.fft import fft, fftfreq, rfft
from plot_serializer.matplotlib.serializer import MatplotlibSerializer
from plotid.publish import publish
from plotid.tagplot import tagplot

# === CONFIGURATION ===
HDF5_PATH = r"/home/pi/nfdi4ing_alex_summer_school_full_code/data/Measurement_Koehler/Measurement_Koehler.hdf5"  # for emample: "data/050625_example_data/050625_example_data.hdf5"
MPLSTYLE_PATH = r"assets/FST.mplstyle"
PLOTS_DIR = r"plots"
PUBLISH_DIR = r"publish"
os.makedirs(PUBLISH_DIR, exist_ok=True)


def main_pub():
    # Copy main.py once
    main_dst = os.path.join(PUBLISH_DIR, "main.py")
    if not os.path.exists(main_dst):
        try:
            shutil.copy("main.py", main_dst)
        except Exception as e:
            print(f"[WARNING] Could not copy main.py: {e}")


def serialize_and_publish_plot(serializer, figs_and_ids, data_path):
    """Serializes a plot to JSON and publishes it to PlotID using the saved image as data.

    Args:
        serializer (MatplotlibSerializer): Plot serializer object.
        figs_and_ids (FiguresAndIDs): Tagged plot object from `tagplot`.
        data_path (str): Path to the PNG image (saved plot) used as src_datapath for publishing.

    Returns:
        None
    """
    plot_id = figs_and_ids.figure_ids[0]
    plot_path = os.path.join(PUBLISH_DIR, f"{plot_id}.json")

    # Save JSON
    filename = os.path.join(PLOTS_DIR, f"{plot_id}.json")
    serializer.write_json_file(filename)
    print(f"[SERIALIZED] JSON: {plot_id}")

    dst_img_path = os.path.join(PLOTS_DIR, os.path.basename(data_path))

    # Publish
    try:
        publish(figs_and_ids, src_datapath=dst_img_path, dst_path=plot_path)
        print(f"[PUBLISHED] PlotID: {plot_id}")
    except Exception as e:
        print(f"[WARNING] Publishing failed: {e}")


def load_data(
    hdf5_path: str,
) -> Tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    list[np.ndarray],
    list[np.ndarray],
    list[str],
]:
    """Loads acceleration and temperature data from an HDF5 file.

    Args:
        hdf5_path (str): Path to the HDF5 file.

    Returns:
        Tuple: Acceleration x, y, z, timestamps, list of temperatures, list of temp timestamps, list of labels.
    """
    with h5py.File(hdf5_path, "r") as f:
        raw = f["RawData"]
        acc_x = acc_y = acc_z = acc_t = None
        temp_data = []
        temp_time = []
        temp_labels = []

        for key in raw:
            g = raw[key]
            if all(
                k in g
                for k in [
                    "acceleration_x",
                    "acceleration_y",
                    "acceleration_z",
                    "timestamp",
                ]
            ):
                acc_x = np.array(g["acceleration_x"])
                acc_y = np.array(g["acceleration_y"])
                acc_z = np.array(g["acceleration_z"])
                acc_t = np.array(g["timestamp"])
            elif "temperature" in g:
                temp_data.append(np.array(g["temperature"]))
                temp_time.append(np.array(g["timestamp"]))
                temp_labels.append(g.attrs.get("name", f"Temp_{key}"))

    if acc_x is None:
        raise ValueError("No acceleration data found in the file.")

    return acc_x, acc_y, acc_z, acc_t, temp_data, temp_time, temp_labels


def filter_data(acc_x, acc_y, acc_z, acc_t, temp_data, temp_time):
    """Filters acceleration and temperature data.

    Args:
        acc_x, acc_y, acc_z, acc_t: Acceleration components and timestamps.
        temp_data, temp_time: Temperature measurements and timestamps.

    Returns:
        Filtered acc_x, acc_y, acc_z, acc_t, temp_data, temp_time.
    """
    valid_indices = (acc_x != 0) | (acc_y != 0) | (acc_z != 0)
    acc_x = acc_x[valid_indices]
    acc_y = acc_y[valid_indices]
    acc_z = acc_z[valid_indices]
    acc_t = acc_t[valid_indices]

    for i in range(len(temp_time)):
        mask = temp_time[i] > 0
        temp_time[i] = temp_time[i][mask]
        temp_data[i] = temp_data[i][mask]

    return acc_x, acc_y, acc_z, acc_t, temp_data, temp_time


def make_equidistant(time: np.ndarray) -> Tuple[np.ndarray]:
    """
    Generates an equidistant time array from a non-equidistant time array.
    Optionally interpolates a signal to the new time base.

    Args:
        time (np.ndarray): Non-equidistant timestamp array.

    Returns:
        Tuple[np.ndarray]:
            - Equidistant time array.
    """
    num_points = len(time)
    if len(time) < 2:
        raise ValueError("Time array must have at least two elements.")

    t_start = time[0]
    t_end = time[-1]

    # Create equidistant time array
    time_uniform = np.linspace(t_start, t_end, num=num_points)

    return time_uniform


def interpolation(
    time: np.ndarray, data: np.ndarray, int_time: np.ndarray
) -> np.ndarray:
    """Linearly interpolates values in data.

    Args:
        time (ndarray): Timestamp of the values in data
        data (ndarray): Values to interpolate
        int_time (ndarray): Points in time at which the data is to be interpolated.

    Returns:
        int_data (ndarray): Interpolation points based on 'time'.
    """
    int_data = np.zeros_like(int_time)

    # Interpolate the values in the data at uniformly distributed
    # interpolation points with a distance of delta_t
    for i, time_i in enumerate(int_time):
        time_diff = time - time_i
        index_l = np.where(time_diff < 0, time_diff, -np.inf).argmax()
        index_r = np.where(time_diff > 0, time_diff, np.inf).argmin()
        time_l = time[index_l]
        data_l = data[index_l]
        data_r = data[index_r]
        time_r = time[index_r]

        dt = time_r - time_l
        int_data[i] = data_l + (time_i - time_l) / dt * (data_r - data_l)

    # int_data = np.interp(int_time, time, data)
    return int_data


def my_fft_scaled(x: np.ndarray, time: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Calculates the FFT of x (with numpy fft() or rfft()) and scales the FFT amplitude.

    It is assumed that the time interval between the sampled sensor data
    is constant.

    Args:
        x (ndarray): Measurement data that are transformed into the
            frequency domain.
        time (ndarray): Timestamp of the measurement data

    Returns:
        (ndarray): Scaled Amplitude of the computed FFT spectrum
        (ndarray): Frequency of the computed FFT spectrum
    """
    x = x - np.average(x)  # Scale data to avoid large amplitude at f=0 Hz
    n = len(x)

    dt = np.diff(time)
    result = np.all(np.round(dt, 10) == np.round(dt[0], 10))
    if ~result:
        print("The data is not equidistant, which is a necessity for the FFT.")
    sr = 1 / np.average(dt)  # compute sampling rate

    # We are only interested in the positive frequency spectrum, this can
    # either be calculated with rfft()
    X_real = rfft(x)
    X_real = 2 * X_real
    X_real = np.absolute(X_real) / len(x)

    freq_real = np.linspace(0, sr / 2, len(X_real))

    # or manually
    # according to section 3.3 in Jens Ahrens, Carl Andersson,
    # Patrik Höstmad, Wolfgang Kropp, “Tutorial on Scaling of
    # the Discrete Fourier Transform and the Implied Physical Units
    # of the Spectra of Time-Discrete Signals” (case real=False).
    X = fft(x)
    # X[0] contains the zero-frequency term
    # X[n/2] contains Neyquist frequency, wenn n is even number
    # X[(n-1)/2] contains largest positive frequency, wenn n is odd
    if (n % 2) == 0:
        X = X[0 : int(n / 2)]
        X[1 : int(n / 2 - 1)] = 2 * X[1 : int(n / 2 - 1)]
    else:
        X = X[0 : int((n - 1) / 2)]
        # For odd n, all bins other than k=0 have to be multiplied with 2.
        X[1:-1] = 2 * X[1:-1]

    X = np.abs(X) / len(x)

    # both formulations are equal
    freq = np.linspace(0, sr / 2, len(X))
    # freq = np.arange(0, len(X)) * sr / (2 * len(X))

    if len(X) <= len(X_real):
        for i, X_i in enumerate(X):
            if ~np.isclose(X_i, X_real[i], rtol=1e-05, atol=1e-02):
                print(
                    "Results from rfft() and fft() differ by {}".format(
                        abs(X_real[i] - X_i)
                    )
                )
    else:
        for i, X_real_i in enumerate(X_real):
            if ~np.isclose(X[i], X_real_i, rtol=1e-05, atol=1e-02):
                print(
                    "Results from rfft() and fft() differ by {}".format(
                        abs(X[i] - X_real_i)
                    )
                )

    return X, freq


def plot_frequency_spectrum(acc_t, acc_mag_detrended):
    """Plots the frequency spectrum of detrended vibration.

    Args:
        acc_t (np.ndarray): Timestamps.
        acc_mag_detrended (np.ndarray): Detrended vibration magnitudes.

    Returns:
        None
    """

    """
    dt = np.mean(np.diff(acc_t))
    fs = 1 / dt
    N = len(acc_mag_detrended)
    frequencies = fftfreq(N, d=dt)
    fft_values = fft(acc_mag_detrended)
    frequencies = frequencies[frequencies > 0]
    amplitudes = np.abs(fft_values[:len(frequencies)]) / N
    """

    acc_t_equidistant = make_equidistant(acc_t)
    acc_mag_interpolated = interpolation(acc_t, acc_mag_detrended, acc_t_equidistant)
    [amplitudes, frequencies] = my_fft_scaled(acc_mag_interpolated, acc_t_equidistant)

    serializer = MatplotlibSerializer()
    fig, ax = serializer.subplots(figsize=(10, 5))

    ax.plot(frequencies, amplitudes, color="#FDCA00")
    ax.set_xlabel("FREQUENCY in Hz", color="black")
    ax.set_ylabel("AMPLITUDE in m/s²", color="black")
    ax.set_title("Frequency Spectrum of Detrended Acceleration Magnitude")
    # ax.grid(True)
    plt.tight_layout()

    # Save the figure image
    fig_scr_path = os.path.join(PLOTS_DIR, "vibration_spectrum.png")
    fig.savefig(fig_scr_path)

    # Tag and publish
    figs_and_ids = tagplot(fig, "matplotlib")
    serializer.add_custom_metadata_figure({"PLOT_ID": figs_and_ids.figure_ids[0]})
    serialize_and_publish_plot(serializer, figs_and_ids, data_path=fig_scr_path)

    plt.show()


def plot_vibration_only(acc_t, acc_mag, title, label_vibration):
    """Plots only the vibration magnitude over time."""
    serializer = MatplotlibSerializer()
    fig, ax = serializer.subplots(figsize=(10, 5))
    ax.plot(acc_t, acc_mag, label=label_vibration, color="#FDCA00")
    ax.set_xlabel("TIME in s", color="black")
    ax.set_ylabel("ACCELERATION in m/s²", color="black")
    ax.tick_params(axis="y", labelcolor="black")
    ax.tick_params(axis="x", labelcolor="black")
    ax.set_title(title)
    # fig.legend(loc="upper left", bbox_to_anchor=(0.07, 0.93), frameon=False)
    plt.tight_layout()

    # Save the figure image
    if title == "Raw Vibration Magnitude over Time":
        fig_scr_path = os.path.join(PLOTS_DIR, "raw_vibration_time.png")
        fig.savefig(fig_scr_path)
    else:
        fig_scr_path = os.path.join(PLOTS_DIR, "detrended_vibration_time.png")
        fig.savefig(fig_scr_path)

    # Tag and publish
    figs_and_ids = tagplot(fig, "matplotlib")
    serializer.add_custom_metadata_figure({"PLOT_ID": figs_and_ids.figure_ids[0]})
    serialize_and_publish_plot(serializer, figs_and_ids, data_path=fig_scr_path)

    plt.show()


def plot_temperature_only(temp_data, temp_time, temp_labels, title):
    """Plots only the temperature data."""

    serializer = MatplotlibSerializer()
    fig, ax = serializer.subplots(figsize=(10, 5))

    for temp, t, label in zip(temp_data, temp_time, temp_labels):
        # Convert to numpy arrays for easy indexing
        temp = np.array(temp)
        t = np.array(t)

        # Filter out NaNs or None
        mask = ~np.isnan(temp) & ~np.isnan(t)
        temp = temp[mask]
        t = t[mask]

        if "environment" in label.lower():
            ax.plot(
                t, temp, linestyle="--", label="Environment Temperature", color="black"
            )
        elif "cup" in label.lower():
            ax.plot(t, temp, linestyle="-", label="Kettle Temperature", color="#004E73")
        else:
            ax.plot(t, temp, linestyle="--", label=label, color="#004E73")

    """
    for temp, t, label in zip(temp_data, temp_time, temp_labels):
        if "environment" in label.lower():
            ax.plot(t, temp, linestyle="--", label="Environment Temperature", color="black")
        elif "cup" in label.lower():
            ax.plot(t, temp, linestyle="-", label="Kettle Temperature", color="#004E73")
        else:
            ax.plot(t, temp, linestyle="--", label=label, color="#004E73")
    """
    ax.set_xlabel("TIME in s", color="black")
    ax.set_ylabel("TEMPERATURE in °C", color="black")
    ax.tick_params(axis="y", labelcolor="black")
    ax.tick_params(axis="x", labelcolor="black")
    ax.set_title(title)
    fig.legend(loc="upper left", bbox_to_anchor=(0.07, 0.93), frameon=False)
    plt.tight_layout()

    # Save the figure image
    fig_scr_path = os.path.join(PLOTS_DIR, "temperature_time.png")
    fig.savefig(fig_scr_path)

    # Tag and publish
    figs_and_ids = tagplot(fig, "matplotlib")
    serializer.add_custom_metadata_figure({"PLOT_ID": figs_and_ids.figure_ids[0]})
    serialize_and_publish_plot(serializer, figs_and_ids, data_path=fig_scr_path)

    plt.show()


def main():
    """Main function for post-processing workflow."""
    plt.style.use(MPLSTYLE_PATH)
    acc_x, acc_y, acc_z, acc_t, temp_data, temp_time, temp_labels = load_data(HDF5_PATH)
    acc_x, acc_y, acc_z, acc_t, temp_data, temp_time = filter_data(
        acc_x, acc_y, acc_z, acc_t, temp_data, temp_time
    )

    acc_mag = np.sqrt(acc_x**2 + acc_y**2 + acc_z**2)
    mean_mag = np.mean(acc_mag)
    acc_mag_detrended = acc_mag - mean_mag

    plot_vibration_only(
        acc_t,
        acc_mag,
        title="Raw Vibration Magnitude over Time",
        label_vibration="Vibration",
    )
    plot_vibration_only(
        acc_t,
        acc_mag_detrended,
        title="Detrended Vibration Magnitude over Time",
        label_vibration="Vibration",
    )
    plot_temperature_only(
        temp_data, temp_time, temp_labels, title="Temperature over Time"
    )

    plot_frequency_spectrum(acc_t, acc_mag_detrended)

    main_pub()


if __name__ == "__main__":
    main()
