## Links
[W3 School Python](https://www.w3schools.com/python/)

[CS50X Lecture 6 Python](https://www.youtube.com/watch?v=EHi0RDZ31VA&list=PLhQjrBD2T381WAHyx1pq-sBfykqMBI7V4&index=7)

[Oh My Git](https://blinry.itch.io/oh-my-git)

[h5py Quick Start Guide](https://docs.h5py.org/en/stable/quick.html)

[NumPy Fundamentals](https://numpy.org/doc/stable/user/basics.html)

[Matplotlib Pyplot Scatter](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html#matplotlib.pyplot.scatter)

[PyPi: W1ThermSensor](https://pypi.org/project/w1thermsensor/)
