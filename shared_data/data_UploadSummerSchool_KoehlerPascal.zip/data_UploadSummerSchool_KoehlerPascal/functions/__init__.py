"""NDFI sommer school project."""

__author__ = "Zhengzhong Gao"
__email__ = "zhengzhong.gao@tu-darmstadt.de"
__version__ = "1.0.2"
