import json
import urllib.parse
from typing import Any, Dict, List, Optional

import requests


def get_metadata_from_setup(file_path: str) -> Dict[str, Any]:
    """Extracts IDs, names, and types from a JSON setup file.

    This function reads setup file with a specific structure and extracts UUIDs, names,
    and types.

    Args:
        file_path (str): File path within the repo to a setup file
            (e.g., 'datasheets/setup.json').
    Returns:
        Dict[str, Any]: Metadata dictionary.

    """
    metadata = initialize_metadata(file_path)
    metadata = add_metadata(file_path, metadata)
    metadata = add_metadata_for_types(metadata)
    metadata = add_temperature_sensor_serials(metadata)

    return metadata


def initialize_metadata(file_path: str) -> Dict[str, Any]:
    """Initializes a dictionary to store metadata.

    This function creates a dictionary intended to store metadata, with the two keys
    `all` and `setup_path`. The value of the entry `all` is itself a dictionary
    containing the keys `values` and `names`, the corresponding values of the dictionary
    are empty lists. The path to the setup file is stored with the key `setup_path` in
    the dictionary. The dictionary structure is shown in the example below.

    Args:
        file_path (str): File path to the JSON setup file.

    Returns:
        Dict[str, Any]: A dictionary with the metadata.

    Example:
        The returned dictionary should have the following structure:
        {
            "all": {
                "values": [], # A list of all UUIDs.
                "names": [], # A list of all names.
            },
            "setup_path": "/path/to/setup_up.json",
        }

    """
    # Initialize a dictionary to store metadata.
    metadata = {"all": {"values": [], "names": []}}
    # Add the path of the setup file to the metadata.
    metadata["setup_path"] = file_path
    return metadata


def add_metadata(file_path: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Appends components UUIDs and corresponding names from a JSON setup file to
    provided the metadata dictionary.

    The UUIDs are stored in the list which is accessed with the two keys `all` and
    `values`, the names are stored in the list which is accessed with the keys `all` and
    `names`.

    To do so, the function reads a JSON setup file located at the given path and
    iterates over all UUIDs. It appends each UUID to the list with the key `values`, and
    its associated name to the list with the key `names`, both of which can be found
    under the key `all` in the metadata dictionary. The dictionary structure is shown in
    the example below.

    Args:
        file_path (str): Path to the JSON setup file.
        metadata (Dict[str, Any]): A dictionary with the metadata.

    Returns:
        Dict[str, Any]: A dictionary with the metadata, filled with UUIDs and component
            names.

    Example:
        The returned dictionary should have the following structure:
        {
            "all": {
                "values": ["uuid_1", "uuid_2", ...], # A list of all UUIDs.
                "names": ["name_1", "name_2", ...], # A list of all names.
            },
            "setup_path": "/path/to/setup_up.json",
        }

    """
    with open(file_path, "r") as file:
        # Load the JSON content from the file.
        setup_data = json.load(file)

    # Iterate over each ID in the setup data of the JSON content.
    for id in get_json_entry(setup_data, ["setup"]):
        # Append the ID to the 'values' list under the 'all' key in metadata.
        metadata["all"]["values"].append(id)
        # Append the corresponding name to the 'names' list under the 'all' key in
        # metadata.
        metadata["all"]["names"].append(get_json_entry_by_uuid(id, ["device", "name"]))

    return metadata


def add_metadata_for_types(metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Adds new dictionaries to the metadata dictionary containing the UUIDs and names
    of only components of certain types.

    This function extracts unique types and updates the metadata dictionary. It adds new
    keys called the same as the types, associating them with a dictionary containing the
    keys `values` and `names`, which store lists of names and UUIDs corresponding to
    that type. The dictionary structure is shown in the example below.

    Args:
        metadata (Dict[str, Any]): A dictionary with the metadata.

    Returns:
        Dict[str, Any]: A dictionary with the metadata, filled with dictionaries for
            different types of components.

    Example:
        The returned dictionary should have the following structure:
        {
            "all": {
                "values": ["uuid_1", "uuid_2", ...],
                "names": ["name_1", "name_2", ...],
            },
            "setup_path": "/path/to/setup_up.json",
            "sensor": {
                "values": ["uuid_1", ...], # A list of all UUIDs with `sensor` type.
                "names": ["name_1", ...], # A list of all names with `sensor` type.
            },
            "type_1": {
                "values": ["uuid_2", ...], # A list of all UUIDs with type_1.
                "names": ["name_2", ...], # A list of all names with type_1.
            },
            ...
        }

    """
    # Initialize an empty set to store unique types.
    types = set()
    for id in metadata["all"]["values"]:
        # Add the type of the current ID to the set of types.
        types.add(get_json_entry_by_uuid(id, ["device", "type"]))
    # For each unique type found, create a new key in the metadata with empty 'values'
    # and 'names' lists.
    for type in types:
        metadata.update({type: {"values": [], "names": []}})
    # Organize IDs and names under their respective type keys in metadata.
    for id in metadata["all"]["values"]:
        type = get_json_entry_by_uuid(id, ["device", "type"])
        metadata[type]["values"].append(id)
        metadata[type]["names"].append(get_json_entry_by_uuid(id, ["device", "name"]))

    return metadata


def add_temperature_sensor_serials(metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Adds the serial number of temperature sensors to the provided metadata
    dictionary.

    This function updates the given dictionary by adding a list of sensor serial numbers
    extracted from JSON data sheets located in the specified folder path. The serial
    numbers are added to the dictionary located at the `sensor` key. There, for the key
    `serials`, a new key-value pair is created, see the example below.

    Args:
        metadata (Dict[str, Any]): The metadata dictionary to be updated. The dictionary
            is expected to have a `sensor` key with a nested `values` key containing
            UUIDs.

    Returns:
        Dict[str, Any]: The updated metadata dictionary.

    Example:
        The returned dictionary should have the following structure:
        {
            "all": {
                "values": ["uuid_1", "uuid_2", ...],
                "names": ["name_1", "name_2", ...],
            },
            "setup_path": "/path/to/setup_up.json",
            # Only for sensor type, there is serials key.
            "sensor": {
                "values": ["uuid_1", ...],
                "names": ["name_1", ...],
                "serials": ["serial_1", ...], # A list of all serials of sensor
            },
            "type_1": {
                "values": ["uuid_2", ...],
                "names": ["name_2", ...],
            },
            ...
        }

    """
    metadata["DS18B20"]["serials"] = [
        get_json_entry_by_uuid(id, ["device", "serial"])
        for id in metadata["DS18B20"]["values"]
    ]

    return metadata


def get_json_entry_by_uuid(uuid: str, json_intern_path: List[str]) -> Any:
    """Searches for a specific JSON value associated with the given UUID in a directory
    structure.

    Args:
        uuid (str): UUID to be searched for within the JSON files.
        json_intern_path (List[str]): A list of keys representing the internal path to
            the desired value within a JSON file.

    Returns:
        Any: JSON value.

    """
    json_data = get_json_file_from_gitlab(uuid)
    json_entry = get_json_entry(json_data, json_intern_path)
    return json_entry


def get_json_entry(json_data: Dict[str, Any], json_intern_path: List[str]) -> Any:
    """Searches for a specific JSON value associated with the given path in a JSON data.

    Args:
        json_data (Dict[str, Any]): The JSON data to search within.
        json_intern_path (List[str]): A list of keys representing the internal path to
            the desired value within the JSON data.

    Returns:
        Any: JSON value or None if not found.

    """
    json_entry = json_data
    try:
        for path in json_intern_path:
            json_entry = json_entry[path]
    except KeyError:
        print(
            "[ERROR] There is no entry <{}> in the provided JSON data".format(
                "->".join(json_intern_path)
            )
        )
        return None
    return json_entry


def get_json_file_from_gitlab(uuid: str) -> Optional[dict]:
    """Retrieves a JSON file from GitLab repository using the provided UUID.

    This function constructs a URL to fetch a device.json file from a specific GitLab
    repository using the UUID as part of the file path. It handles various HTTP response
    codes and returns the parsed JSON data or prints appropriate error messages.

    Args:
        uuid (str): UUID used to construct the file path for the device.json file.

    Returns:
        Optional[dict]: The parsed JSON data from the retrieved file, or None if an
            error occurs.

    Raises:
        None: Errors are handled internally and printed to console.

    """
    file_path = "{}/device.json".format(uuid)
    file_path = urllib.parse.quote(file_path, safe="")
    url = "https://git.rwth-aachen.de/api/v4/projects/114763/repository/files/{}/raw?ref=main".format(
        file_path
    )
    response = requests.get(url)
    if response.status_code == 200:
        try:
            json_entry = json.loads(response.text)
            return json_entry
        except json.JSONDecodeError:
            print("[ERROR] JSON file <{}/device.json> is not valid.".format(uuid))
    elif response.status_code == 404:
        print("[ERROR] JSON file <{}/device.json> not found.".format(uuid))
    elif response.status_code == 403:
        print("[ERROR] Access to <{}> is forbidden.".format(url))
    else:
        print("[ERROR] Failed to load JSON: {}".format(response.status_code))
